function getCart() { return JSON.parse(localStorage.getItem('fornoCarrinho')) || []; }
function saveCart(cart) { localStorage.setItem('fornoCarrinho', JSON.stringify(cart)); updateCartCount(); }
function updateCartCount() { const cart = getCart(); const totalQty = cart.reduce((sum, item) => sum + item.qtd, 0); document.querySelectorAll('.carrinho span').forEach(span => span.textContent = totalQty); }
updateCartCount();
function parsePreco(str) { let limpo = str.replace(/[^0-9,]/g, '').replace(',', '.'); return parseFloat(limpo) || 0; }
if (window.location.pathname.includes('contactos.html')) {
    const formContacto = document.querySelector('form');
    if (formContacto) { formContacto.addEventListener('submit', function(e) { e.preventDefault(); alert('A sua mensagem foi enviada com sucesso! Entraremos em contacto brevemente.'); formContacto.reset(); }); }
}
document.querySelectorAll('.botao').forEach(botao => {
    botao.addEventListener('click', function(e) {
        const texto = this.textContent.toLowerCase();
        if (this.id === 'btn-finalizar') return;
        if (texto.includes('adicionar') && !window.location.pathname.includes('monta.html')) {
            e.preventDefault(); let cartao = this.closest('.cartao');
            if(cartao) {
                let nome = cartao.querySelector('h3').textContent; let preco = parsePreco(cartao.querySelector('.preco').textContent);
                let cart = getCart(); let existing = cart.find(i => i.nome === nome);
                if(existing) { existing.qtd++; } else { cart.push({nome: nome, preco: preco, qtd: 1}); }
                saveCart(cart); alert(nome + ' adicionada ao carrinho!');
            }
        }
    });
});
if (window.location.pathname.includes('encomendas.html')) {
    const lista = document.getElementById('lista-carrinho'); const totalEl = document.getElementById('total-carrinho');
    function renderCart() {
        let currentCart = getCart(); if (!lista) return; lista.innerHTML = ''; let total = 0;
        if(currentCart.length === 0) { 
            lista.innerHTML = '<li><span>O carrinho está vazio.</span></li>'; 
            if(totalEl) totalEl.textContent = '€0,00'; 
        } else {
            currentCart.forEach((item, index) => {
                let li = document.createElement('li'); 
                let subtotal = (item.preco * item.qtd).toFixed(2).replace('.',',');
                li.innerHTML = '<span>' + item.qtd + ' × ' + item.nome + '</span><span class=\'preco\'>€' + subtotal + ' <button class=\'btn-apagar\' data-index=\'' + index + '\' title=\'Remover\' style=\'background:#C0392B; color:white; border:none; border-radius:50%; width:24px; height:24px; cursor:pointer;\'>&times;</button></span>';
                lista.appendChild(li); total += item.preco * item.qtd;
            });
            if(totalEl) totalEl.textContent = '€' + total.toFixed(2).replace('.',',');
        }
        document.querySelectorAll('.btn-apagar').forEach(btn => { btn.addEventListener('click', function() { let c = getCart(); c.splice(this.getAttribute('data-index'), 1); saveCart(c); renderCart(); }); });
    }
    renderCart();
    const btnFinalizar = document.getElementById('btn-finalizar');
    if (btnFinalizar) {
        btnFinalizar.addEventListener('click', function(e) {
            e.preventDefault(); if(getCart().length === 0) { alert('O teu carrinho está vazio!'); return; }
            const modal = document.getElementById('modal-loading'); if(modal) modal.style.display = 'flex';
            localStorage.removeItem('fornoCarrinho'); updateCartCount(); renderCart();
            setTimeout(() => {
                if(modal) { 
                    let html = '<div style=\'background: white; padding: 3rem 2rem; border-radius: 12px; text-align: center; max-width: 400px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);\'>';
                    html += '<h2 style=\'color: #C0392B; margin-top: 0; margin-bottom: 1.5rem; font-size: 2.2rem; line-height: 1.1;\'>A tua pizza está a caminho! 🍕</h2>';
                    html += '<img src=\'img/logo-icone.webp\' alt=\'Logo\' style=\'width: 120px; height: 120px; border-radius: 50%; border: 3px solid #C0392B; margin: 0 auto 1.5rem auto; object-fit: contain; background: #fff; display: block;\'>';
                    html += '<p style=\'color: #666; margin-bottom: 2rem; font-size: 1.1rem;\'>Obrigado pela tua encomenda.</p>';
                    html += '<a href=\'index.html\' class=\'botao\' style=\'width: 100%; box-sizing: border-box; display: block; color: white; text-decoration: none;\'>Voltar ao Início</a></div>';
                    modal.innerHTML = html;
                }
            }, 3000);
        });
    }
}
if (window.location.pathname.includes('monta.html')) {
    const inputs = document.querySelectorAll('input[type=\'radio\'], input[type=\'checkbox\']');
    function calcularPreco() {
        let preco = 0; const tamanho = document.querySelector('input[name=\'tamanho\']:checked'); if (tamanho) preco += parseFloat(tamanho.value);
        let listaIngredientes = []; const ingredientes = document.querySelectorAll('input[type=\'checkbox\']:checked');
        ingredientes.forEach(ing => { preco += parseFloat(ing.value); listaIngredientes.push(ing.parentElement.textContent.split('+')[0].trim()); });
        const massa = document.querySelector('input[name=\'massa\']:checked'); const nomeMassa = massa ? massa.parentElement.textContent.trim() : 'Fina';
        const nomeTamanho = tamanho ? tamanho.parentElement.textContent.split('€')[0].trim() : 'Média';
        const itensResumo = document.querySelectorAll('.monta-resumo ul li');
        if (itensResumo.length >= 3) { itensResumo[0].textContent = 'Massa: ' + nomeMassa; itensResumo[1].textContent = 'Tamanho: ' + nomeTamanho; itensResumo[2].textContent = 'Ingredientes: ' + (listaIngredientes.length > 0 ? listaIngredientes.join(', ') : 'nenhum'); }
        const precoTotal = document.querySelector('.total strong'); if (precoTotal) precoTotal.textContent = '€' + preco.toFixed(2).replace('.', ',');
        const previaDiv = document.querySelector('.monta-previa');
        if (previaDiv) { 
            let ings = listaIngredientes.length > 0 ? listaIngredientes.join(', ') : 'Nenhum extra'; 
            let html = '<img src=\'img/logo-icone.webp\' alt=\'Logo\' style=\'width: 90px; height: 90px; margin: 0 auto 10px auto; display: block; border-radius: 50%; border: 2px solid #C0392B; background: white; object-fit: contain;\'>';
            html += '<h3 style=\'color: #C0392B; margin-bottom: 5px;\'>' + nomeMassa + ' | ' + nomeTamanho + '</h3>';
            html += '<p style=\'font-size: 0.9rem; color: #444;\'><strong>Extras:</strong> ' + ings + '</p>';
            previaDiv.innerHTML = html;
        }
    }
    inputs.forEach(input => input.addEventListener('change', calcularPreco)); calcularPreco();
    const btnAdd = document.getElementById('btn-add-monta');
    if (btnAdd) { btnAdd.addEventListener('click', function(e) { e.preventDefault(); let preco = parsePreco(document.querySelector('.total strong').textContent); let cart = getCart(); cart.push({nome: 'Pizza Personalizada', preco: preco, qtd: 1}); saveCart(cart); alert('Pizza Personalizada adicionada ao carrinho!'); }); }
}